public class Quit extends LibraryAction implements Action {
  public Quit(String key) {
    super(key);
  }
}
